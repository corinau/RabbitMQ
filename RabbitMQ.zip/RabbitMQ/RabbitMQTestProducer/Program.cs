﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System.Text;

public class MainClass
{
    public static void Main(string[] args)
    {
        const int RETRY = 1;
        const int RETRY_LIMIT = 3;

        var factory = new ConnectionFactory
        {
            HostName = "localhost",
            UserName = "guest",
            Password = "guest"
        };
        //automatic connection recovery
        factory.AutomaticRecoveryEnabled = true;
        //create the RabbitMQ connection using connection factory details mentioned above
        using (var connection = factory.CreateConnection())
        {
            using (var channel = connection.CreateModel())
            {
                //Here we create channel with session and model
                //durable options let the tasks survive even if RabbitMQ is restarted.
                channel.QueueDeclare("myQueue", durable: true, exclusive: false, autoDelete: false, arguments: null);
                channel.ExchangeDeclare("myQueueExchange", type: ExchangeType.Fanout, true, false, null);

                channel.QueueBind("myQueue", "myQueueExchange", "myRoutingKey");

                int messageCount = 1;

                while(true)
                {
                    var message = new MyMessage { Id = messageCount, Description = "This is my message " + messageCount, Count = 1, Status = "Delivered" };
                    var json = JsonConvert.SerializeObject(message);
                    var body = Encoding.UTF8.GetBytes(json);

                    IBasicProperties props = channel.CreateBasicProperties();
                    props.Persistent = true;
                    props.Headers = new Dictionary<string, object>();
                    props.Headers.Add("x-retry", RETRY);
                    props.Headers.Add("x-retry-limit", RETRY_LIMIT);
                    props.Headers.Add("x-publish-date", DateTime.Now.ToString());

                    channel.BasicPublish("myQueueExchange", "myRoutingKey", props, body);

                    messageCount++;

                    Console.WriteLine("Send message with Id = {0} and Description: {1}", message.Id, message.Description);
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                    
                }
            }
        }
    }

    public class MyMessage
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public int Count { get; set; }
        public string? Status { get; set; }
    }
}