﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

public class MainClass
{
    const int QUEUE_RETRY_LIMIT = 3;
    const int QUEUE_DELAY = 12000;

    public static void Main(string[] args)
    {
        var factory = new ConnectionFactory
        {
            HostName = "localhost",
            UserName = "guest",
            Password = "guest"
        };

        using (var connection = factory.CreateConnection())
        {
            using (var channel = connection.CreateModel())
            {
                var queueArgs = new Dictionary<string, object>();
                queueArgs.Add("x-delayed-type", "fanout");
                queueArgs.Add("dead-letter-exchange", "DLX.DEAD.LETTERS");

                channel.ExchangeDeclare("myQueueExchange", type: ExchangeType.Fanout, true, false, arguments: queueArgs);
                channel.QueueDeclare("myQueue", durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
                channel.QueueBind("myQueue", "myQueueExchange", "myRoutingKey", null);

                var consumer = new EventingBasicConsumer(channel);

                consumer.Received += (model, result) =>
                            {
                                var retry = Convert.ToInt32(result.BasicProperties.Headers["x-retry"]);
                                var limit_retry = Convert.ToInt32(result.BasicProperties.Headers["x-retry-limit"]);

                                var publish_date = Convert.ToDateTime(Encoding.UTF8.GetString((byte[])result.BasicProperties.Headers["x-publish-date"]));

                                var body = result.Body.ToArray();
                                var message = Encoding.UTF8.GetString(body);
                                var myMessage = JsonConvert.DeserializeObject<MyMessage>(message);

                                // Process the message
                                if (publish_date <= DateTime.Now)
                                {
                                    Console.WriteLine("Received messsage with Id = {0}, publish date = {1} and now date = {2}", myMessage?.Id, publish_date.ToString(), DateTime.Now.ToString());

                                    if (myMessage.Id % 2 == 0)
                                    {
                                        Task.Run(() => ProcessMessageCommand(myMessage, retry, limit_retry, publish_date));
                                    }
                                    else
                                    {
                                        // Process the message here ... e.g. save to DB
                                        //here we do nothing, just remove it from queue
                                        Console.WriteLine("Remove messsage with Id = {0}\n", myMessage?.Id);
                                    }

                                    //positively acknoledge a single delivery, the message will be discarded
                                    channel.BasicAck(result.DeliveryTag, false);
                                }
                                else
                                {
                                    //requeue the delivery
                                    channel.BasicReject(result.DeliveryTag, true);
                                }
                            };


                channel.BasicConsume("myQueue", false, consumer);

                Console.WriteLine("Consuming myQueue");
                Console.ReadKey();
            }
        }
    }

    public class MyMessage
    {
        public int Id { get; set; }
        public string? Status { get; set; }
        public string? Description { get; set; }
        public int Count { get; set; }
    }

    public class MessageEvent
    {
        public int Id { get; set; }
        public int Count { get; set; }
        public string? Description { get; set; }
        public string? Status { get; set; }

    }

    private static void ProcessMessageCommand(MyMessage msg, int retry, int limit, DateTime publish_date)
    {
        // Logic to process the order command asynchronously
        Console.WriteLine($"Processing message with Id = {msg.Id} and Description: {msg.Description}. Retry = {retry}");

        // Place order, perform validation, etc.
        // If successful, publish an order processed event
        var msgEvent = new MessageEvent { Id = msg.Id, Status = "Processed", Count = msg.Count + 1, Description = msg.Description };
        SendMessageProcessedEvent(msgEvent, retry + 1, limit, publish_date);
    }

    private static void SendMessageProcessedEvent(MessageEvent msgEvent, int retry, int limit, DateTime publish_date)
    {
        var queueArgs = new Dictionary<string, object>();
        queueArgs.Add("x-retry-limit", QUEUE_RETRY_LIMIT);
        queueArgs.Add("x-delay", QUEUE_DELAY);
        queueArgs.Add("x-delayed-type", "direct");

        var eventQueueName = "myQueue_retry";
        var queueRetryExchange = "myQueue_retry_exchange";

        var factory = new ConnectionFactory() { HostName = "localhost" };
        using var connection = factory.CreateConnection();
        using var channel = connection.CreateModel();
        channel.ExchangeDeclare(queueRetryExchange, type: ExchangeType.Direct, true, false, arguments: queueArgs);
        channel.QueueDeclare(queue: eventQueueName, durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);
        channel.QueueBind(eventQueueName, queueRetryExchange, "", null);

        var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(msgEvent));

        IBasicProperties props = channel.CreateBasicProperties();

        props.Headers = new Dictionary<string, object>();
        props.Headers.Add("x-retry", retry);
        props.Headers.Add("x-retry-limit", limit);
        props.Headers.Add("x-publish-date", publish_date.AddSeconds(20).ToString());
        //props.Headers.Add("x-delay", 20000);

        channel.BasicPublish(exchange: "", routingKey: eventQueueName, basicProperties: props, body: body);
        Console.WriteLine($"Message with Id = {msgEvent.Id} processed\n");
    }
}
