﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

public class MainClass
{
    const int RETRY_DELAY = 12000;
    const int QUEUE_DELIVERY_COUNT = 3;
    const int QUEUE_RETRY = 3;
    const int QUEUE_RETRY_LIMIT = 3;
    const int QUEUE_DELAY = 12000;

    public static void Main(string[] args)
    {
        var factory = new ConnectionFactory
        {
            HostName = "localhost",
            UserName = "guest",
            Password = "guest"
        };

        using (var connection = factory.CreateConnection())
        {
            using (var channel = connection.CreateModel())
            {
                var queueArgs = new Dictionary<string, object>();
                queueArgs.Add("x-delayed-type", "fanout");
                queueArgs.Add("dead-letter-exchange", "DLX.DEAD.LETTERS");

                channel.QueueDeclare("myQueue_retry", durable: true, exclusive: false, autoDelete: false, arguments: queueArgs);

                var consumer = new EventingBasicConsumer(channel);

                consumer.Received += (model, result) =>
                {
                    var retry = Convert.ToInt32(result.BasicProperties.Headers["x-retry"]);
                    var limit_retry = Convert.ToInt32(result.BasicProperties.Headers["x-retry-limit"]);
                    var publish_date = Convert.ToDateTime(Encoding.UTF8.GetString((byte[])result.BasicProperties.Headers["x-publish-date"]));

                    var body = result.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var myMessage = JsonConvert.DeserializeObject<MyMessage>(message);

                    Console.WriteLine("Received messsage with Id = {0}, publish date = {1} and now date = {2}. This is {3} retry", myMessage?.Id, publish_date.ToString(), DateTime.Now.ToString(), retry.ToString());
                    // Process the message
                    Task.Run(() => ProcessMessageCommand(myMessage, retry, limit_retry, publish_date));
                    if (retry <= limit_retry)
                    {
                        channel.BasicAck(result.DeliveryTag, false);
                    }
                    else
                    {
                        //do something and remove from queue
                        channel.BasicReject(result.DeliveryTag, false);
                    }
                };


                channel.BasicConsume("myQueue_retry", false, consumer);

                Console.WriteLine("Consuming myQueue_retry");
                Console.ReadKey();
            }
        }
    }

    public class MyMessage
    {
        public int Id { get; set; }
        public string? Status { get; set; }
        public string? Description { get; set; }
        public int Count { get; set; }
    }

    public class MessageEvent
    {
        public int Id { get; set; }
        public string? Status { get; set; }
        public int Count { get; set; }
        public string? Description { get; set; }
    }

    private static void ProcessMessageCommand(MyMessage msg, int retry, int limit, DateTime publish_date)
    {
        // Logic to process the order command asynchronously
        // Place order, perform validation, etc.
        // If successful, publish an order processed event
        var msgEvent = new MessageEvent { Id = msg.Id, Status = "Processed", Count = msg.Count + 1 };
        SendMessageProcessedEvent(msgEvent, retry, limit, publish_date);
    }

    private static void SendMessageProcessedEvent(MessageEvent msgEvent, int retry, int limit, DateTime publish_date)
    {
        if (retry <= limit)
        {
            var eventQueueName = "myQueue";
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();
            channel.QueueDeclare(queue: eventQueueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
            var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(msgEvent));

            IBasicProperties props = channel.CreateBasicProperties();
            props.DeliveryMode = 2;

            props.Headers = new Dictionary<string, object>();
            props.Headers.Add("x-retry", retry);
            props.Headers.Add("x-retry-limit", limit);
            props.Headers.Add("x-publish-date", publish_date.ToString());

            channel.BasicPublish(exchange: "myQueueExchange", routingKey: eventQueueName, basicProperties: props, body: body);
            Console.WriteLine($"Message with Id = {msgEvent.Id} processed and sent to original queue\n");
        }
        else
        {
            Console.WriteLine("Retry number {0} exceeded limit {1}\n", retry, limit);
        }
    }
}
